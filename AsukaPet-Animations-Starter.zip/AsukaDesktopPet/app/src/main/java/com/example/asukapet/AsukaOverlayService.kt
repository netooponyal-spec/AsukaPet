package com.example.asukapet

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class AsukaOverlayService : Service(), TextToSpeech.OnInitListener {
    companion object {
        // Set ASUKA_BACKEND_URL in app/build.gradle.kts. Keep provider API keys on the server.
        private const val BACKEND_URL = BuildConfig.ASUKA_BACKEND_URL
    }

    private lateinit var wm: WindowManager
    private lateinit var sprite: ImageView
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var added = false
    private var downX = 0
    private var downY = 0
    private var startX = 0
    private var startY = 0
    private val history = JSONArray()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        recognizer = if (SpeechRecognizer.isRecognitionAvailable(this)) SpeechRecognizer.createSpeechRecognizer(this) else null
        addSprite()
    }

    private fun addSprite() {
        sprite = ImageView(this).apply {
            setImageResource(R.drawable.asuka_sprite)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Аска. Нажми, чтобы поговорить"
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX.toInt()
                        downY = event.rawY.toInt()
                        startX = params.x
                        startY = params.y
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX.toInt() - downX)
                        params.y = startY + (event.rawY.toInt() - downY)
                        wm.updateViewLayout(sprite, params)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = kotlin.math.abs(event.rawX.toInt() - downX)
                        val dy = kotlin.math.abs(event.rawY.toInt() - downY)
                        if (dx < 12 && dy < 12) listen()
                        true
                    }
                    else -> false
                }
            }
        }
        params = WindowManager.LayoutParams(
            dp(112), dp(144),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(180)
        }
        wm.addView(sprite, params)
        added = true
        sprite.animate().translationYBy(-dp(10).toFloat()).setDuration(650).withEndAction {
            sprite.animate().translationYBy(dp(10).toFloat()).setDuration(650).start()
        }.start()
    }

    private lateinit var params: WindowManager.LayoutParams

    private fun listen() {
        val sr = recognizer
        if (sr == null) {
            say("У тебя распознавание речи недоступно. Проверь сервисы Google.")
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори, я слушаю…")
            }
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { sayStatus("Слушаю…") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { sayStatus("Думаю…") }
                override fun onError(error: Int) { sayStatus("Не расслышала. Нажми и попробуй ещё раз.") }
                override fun onResults(results: Bundle?) {
                    val message = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!message.isNullOrBlank()) askAi(message)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            sr.startListening(intent)
        } catch (_: Exception) {
            say("Не получилось включить микрофон. Проверь разрешение на запись звука.")
        }
    }

    private fun askAi(message: String) {
        // Offline fallback, so the starter remains demonstrable before a backend is configured.
        if (BACKEND_URL.contains("YOUR-SERVER") || BACKEND_URL.isBlank()) {
            say("Я услышала: $message. Подключи ИИ-сервер, и тогда я смогу нормально отвечать, а не просто повторять.")
            return
        }
        thread {
            var reply = "Что-то пошло не так. Попробуй ещё раз."
            try {
                val conn = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 12000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("message", message).put("history", history).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                reply = JSONObject(response).optString("reply", reply)
                conn.disconnect()
                synchronized(history) {
                    history.put(JSONObject().put("role", "user").put("content", message))
                    history.put(JSONObject().put("role", "assistant").put("content", reply))
                    while (history.length() > 20) history.remove(0)
                }
            } catch (_: Exception) {}
            val finalReply = reply
            android.os.Handler(mainLooper).post { say(finalReply) }
        }
    }

    private fun say(text: String) {
        sayStatus(text)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "asuka_reply")
        sprite.animate().scaleX(1.08f).scaleY(1.08f).setDuration(180).withEndAction {
            sprite.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
        }.start()
    }

    private fun sayStatus(text: String) {
        Toast.makeText(this, text.take(180), Toast.LENGTH_SHORT).show()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
            tts?.setSpeechRate(1.05f)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (added) {
            try { wm.removeView(sprite) } catch (_: Exception) {}
        }
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
