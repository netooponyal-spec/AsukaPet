# Asuka Pet — Android + AI backend starter

Это стартовый проект, а не готовый APK. В нём есть плавающий персонаж, голосовой ввод Android и озвучка ответов; backend подключает настоящую модель ИИ. Персонаж сейчас временный векторный placeholder.

## Важно
- Секретный `OPENAI_API_KEY` хранится только на сервере, не в APK. Это соответствует рекомендациям OpenAI: https://developers.openai.com/api/reference/overview
- Для ИИ нужен интернет, API-ключ и доступ к выбранной модели. Использование API может быть платным отдельно от подписки ChatGPT.
- Приложение пока слушает одну реплику после нажатия на персонажа. Это не постоянное прослушивание; непрерывный режим можно добавить отдельно.
- Проект не собран и не протестирован на физическом устройстве.

## 1. Запуск backend
На компьютере с Python 3.11+ или на хостинге, который поддерживает Docker/Python:

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
````

Скопируй `.env.example` в `.env` и задай `OPENAI_API_KEY` и, если нужно, `OPENAI_MODEL`. Затем загрузи переменную окружения в терминале и запусти:

```bash
# macOS/Linux
export OPENAI_API_KEY="твой_ключ"
uvicorn main:app --host 0.0.0.0 --port 8000
```

Для реального использования разверни backend с HTTPS. Не выставляй простой локальный сервер в интернет без защиты от злоупотреблений и лимитов. Endpoint: `https://ТВОЙ-ДОМЕН/api/chat`.

## 2. Подключение Android-приложения
Открой проект в Android Studio. В `app/build.gradle.kts` замени `https://YOUR-SERVER.example/api/chat` на URL своего HTTPS backend. Выполни Gradle Sync и запусти на телефоне.

В приложении нажми «Включить Аску», разреши микрофон и показ поверх других приложений. Затем нажми на Аску и говори по-русски. Android распознаёт речь, backend получает текст, ответ ИИ озвучивается системным Text-to-Speech.

## 3. Если хочешь делать всё с телефона
Этот проект — исходный код, не APK. Собирать Android-проект удобнее в Android Studio на ПК. На самом телефоне можно экспериментировать с Android IDE, например AIDE, но поддержка современных Gradle-плагинов может отличаться. Для настоящего ИИ backend всё равно должен быть доступен по HTTPS; один только телефон не отменяет безопасное хранение API-ключа.

## API контракт
`POST /api/chat`
```json
{"message":"Привет, Аска!", "history": []}
```
Ответ: `{"reply":"Чего тебе? ..."}`

Проверка backend: `GET /health`.


## Animation update (0.3.0)
- Added a gentle idle floating animation.
- Added visual reactions when listening, thinking, and speaking.
- Real AI responses still require deploying the backend and setting ASUKA_BACKEND_URL.
- Distinct facial expressions/poses need additional sprite images; this update animates the current sprite.
