plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.asukapet"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.asukapet"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.2.0"
        // Replace with your deployed HTTPS backend URL before building the APK.
        buildConfigField("String", "ASUKA_BACKEND_URL", "\"https://YOUR-SERVER.example/api/chat\"")
    }
    buildFeatures {
        buildConfig = true
    }
}
