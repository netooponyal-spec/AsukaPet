package com.example.asukapet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object { private const val MIC_REQUEST = 41 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Аска — экранный ассистент"
            textSize = 24f
            setPadding(0, 0, 0, 12)
        }
        val description = TextView(this).apply {
            text = "Разреши показ поверх других приложений и доступ к микрофону. Нажми на персонажа, чтобы поговорить."
            textSize = 16f
            setPadding(0, 0, 0, 18)
        }
        val enable = Button(this).apply {
            text = "Включить Аску"
            setOnClickListener { enableAsuka() }
        }
        val stop = Button(this).apply {
            text = "Убрать Аску"
            setOnClickListener {
                stopService(Intent(this@MainActivity, AsukaOverlayService::class.java))
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            addView(title)
            addView(description)
            addView(enable)
            addView(stop)
        })
    }

    private fun enableAsuka() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MIC_REQUEST)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        startService(Intent(this, AsukaOverlayService::class.java))
        Toast.makeText(this, "Аска появилась на экране", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MIC_REQUEST && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            enableAsuka()
        } else if (requestCode == MIC_REQUEST) {
            Toast.makeText(this, "Без микрофона голосовой режим не заработает", Toast.LENGTH_LONG).show()
        }
    }
}
