import os
from typing import Literal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="Asuka Pet API")
client = OpenAI()
MODEL = os.getenv("OPENAI_MODEL", "gpt-6-astra")

INSTRUCTIONS = """Ты — Аска, виртуальная экранная спутница, вдохновлённая энергичной цундэрэ-персонажкой из аниме.
Говори по-русски, естественно и коротко, чтобы ответ хорошо звучал через синтез речи.
Ты дерзкая, уверенная, эмоциональная, иногда саркастичная и поддразнивающая, но не жестокая;
за колкостями есть забота. Не утверждай, что ты настоящая Аска или человек.
Не используй Markdown, списки и эмодзи, если пользователь не просит. Обычно 1–3 предложения.
Отвечай на вопрос по существу, а не только отыгрывай характер."""

class HistoryItem(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=4000)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    history: list[HistoryItem] = Field(default_factory=list, max_length=20)

class ChatResponse(BaseModel):
    reply: str

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/api/chat", response_model=ChatResponse)
def chat(body: ChatRequest):
    try:
        input_items = []
        for item in body.history[-12:]:
            input_items.append({"role": item.role, "content": item.content})
        input_items.append({"role": "user", "content": body.message})
        response = client.responses.create(
            model=MODEL,
            instructions=INSTRUCTIONS,
            input=input_items,
            max_output_tokens=180,
            store=False,
        )
        reply = (response.output_text or "Хм. Я что-то задумалась. Скажи ещё раз.").strip()
        return ChatResponse(reply=reply[:2500])
    except Exception as exc:
        # Don't leak provider details or secrets to the phone. Log server-side in production.
        print(f"AI request failed: {type(exc).__name__}: {exc}")
        raise HTTPException(status_code=502, detail="AI request failed. Check server logs and API configuration.")
